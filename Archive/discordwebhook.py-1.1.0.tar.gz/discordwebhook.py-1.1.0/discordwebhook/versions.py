
class Current:
    name = "1.1.0"
    release_date = "5 Febuary 2022"
