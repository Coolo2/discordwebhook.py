class version:
    class recent():
        name = "0.0.5"
        release_date = "28 July 2020"