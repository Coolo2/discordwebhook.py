
from discordwebhook import versions, webhook, embed, allowedmentions


Webhook = webhook.Webhook
Embed = embed.Embed
AllowedMentions = allowedmentions.AllowedMentions

CurrentVersion = versions.Current