class version:
    class current:
        name = "0.0.7"
        release_date = "28 July 2020"
    
    recent = current