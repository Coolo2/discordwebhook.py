
class Current:
    name = "1.0.1"
    release_date = "30 January 2022"
