class version:
    class current:
        name = "0.0.9"
        release_date = "29 July 2020"
    
    recent = current