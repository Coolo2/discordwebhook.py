class version:
    class current:
        name = "0.0.8"
        release_date = "28 July 2020"
    
    recent = current