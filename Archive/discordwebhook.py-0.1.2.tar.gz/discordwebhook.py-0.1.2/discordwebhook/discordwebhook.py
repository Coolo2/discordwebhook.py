class version:
    class current:
        name = "0.1.2"
        release_date = "29 July 2020"
    
    recent = current