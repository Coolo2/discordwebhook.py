
class Current:
    name = "1.1.2"
    release_date = "6 August 2022"
